const SCRIPT_URL = 'YOUR_WEB_APP_URL_HERE'; // *** IMPORTANT: Replace with your deployed Google Apps Script Web App URL ***

const voteButtons = document.querySelectorAll('.vote-button');
const showResultsBtn = document.getElementById('showResultsBtn');
const messageElement = document.getElementById('message');
const resultsList = document.getElementById('resultsList');
const resultsContainer = document.getElementById('results');

// To prevent multiple votes from the same browser session (basic protection)
let hasVoted = localStorage.getItem('hasVotedSimpleVotingApp') === 'true';

// Initial state of results container (hidden)
resultsContainer.style.display = 'none';

// Add event listeners to vote buttons
voteButtons.forEach(button => {
    button.addEventListener('click', async () => {
        if (hasVoted) {
            displayMessage('You have already voted in this session!', 'error');
            return;
        }

        const voteOption = button.dataset.option;
        displayMessage('Submitting your vote...', '');

        try {
            // Get IP address and user agent (basic client-side info)
            const ipResponse = await fetch('https://api.ipify.org?format=json');
            const ipData = await ipResponse.json();
            const ipAddress = ipData.ip || 'Unknown';
            const userAgent = navigator.userAgent || 'Unknown';

            const response = await fetch(SCRIPT_URL, {
                method: 'POST',
                mode: 'cors', // Crucial for cross-origin requests
                headers: {
                    'Content-Type': 'text/plain;charset=utf-8', // Content-Type for Apps Script POST
                },
                body: JSON.stringify({
                    voteOption: voteOption
                }),
                // Append IP and User-Agent as query parameters for Apps Script to potentially read
                // Note: Apps Script's e.parameter only gets query params, not body data directly.
                // We're sending voteOption in body, and IP/UA in query for simplicity and demo.
                // For production, you might send all in body and parse differently in Apps Script.
            }) + `?ip_address=${encodeURIComponent(ipAddress)}&user_agent=${encodeURIComponent(userAgent)}`;


            const result = await response.json(); // Parse the JSON response from Apps Script

            if (result.success) {
                displayMessage(`Successfully voted for: ${voteOption}!`, 'success');
                hasVoted = true;
                localStorage.setItem('hasVotedSimpleVotingApp', 'true');
                disableVoteButtons();
                // Optionally show results immediately after voting
                fetchAndDisplayResults();
            } else {
                displayMessage(`Error: ${result.message}`, 'error');
            }
        } catch (error) {
            console.error('Error submitting vote:', error);
            displayMessage('An error occurred while submitting your vote. Please try again.', 'error');
        }
    });
});

// Add event listener to show results button
showResultsBtn.addEventListener('click', fetchAndDisplayResults);

// Function to fetch and display results
async function fetchAndDisplayResults() {
    displayMessage('Fetching results...', '');
    try {
        const response = await fetch(SCRIPT_URL); // GET request to fetch data
        const data = await response.json(); // Assuming the Apps Script will return JSON results

        if (data.success && data.results) {
            resultsList.innerHTML = ''; // Clear previous results
            // Convert results object to array for sorting/display
            const sortedResults = Object.entries(data.results).sort(([, a], [, b]) => b - a);

            if (sortedResults.length === 0) {
                resultsList.innerHTML = '<li>No votes cast yet.</li>';
            } else {
                sortedResults.forEach(([option, count]) => {
                    const listItem = document.createElement('li');
                    listItem.innerHTML = `<span>${option}</span> <span>${count} votes</span>`;
                    resultsList.appendChild(listItem);
                });
            }
            resultsContainer.style.display = 'block'; // Show the results section
            displayMessage('Results updated!', 'success');
        } else {
            displayMessage(`Error fetching results: ${data.message || 'Unknown error'}`, 'error');
            resultsContainer.style.display = 'none';
        }
    } catch (error) {
        console.error('Error fetching results:', error);
        displayMessage('An error occurred while fetching results. Please try again later.', 'error');
        resultsContainer.style.display = 'none';
    }
}

// Helper function to display messages
function displayMessage(msg, type = '') {
    messageElement.textContent = msg;
    messageElement.className = 'message ' + type; // Add type class for styling (e.g., 'error')
}

// Helper function to disable vote buttons after voting
function disableVoteButtons() {
    voteButtons.forEach(button => {
        button.disabled = true;
        button.style.opacity = 0.6;
        button.style.cursor = 'not-allowed';
    });
}

// Initial check to disable buttons if already voted
if (hasVoted) {
    disableVoteButtons();
    displayMessage('You have already voted in this session!', 'info'); // 'info' is a custom type for general messages
}

// Add a GET handler to your Google Apps Script for fetching results
// Go back to your Google Apps Script (Code.gs) and modify the doGet function:
/*
const SPREADSHEET_ID = 'YOUR_SPREADSHEET_ID_HERE';
const SHEET_NAME = 'Sheet1';

function doGet(e) {
  const sheet = SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues(); // Get all data from the sheet

  // Assuming first row is headers, skip it
  if (data.length < 2) {
    return ContentService.createTextOutput(JSON.stringify({ success: true, results: {}, message: "No votes yet." }))
      .setMimeType(ContentService.MimeType.JSON);
  }

  const votes = {};
  // Iterate from the second row (index 1) to count votes
  for (let i = 1; i < data.length; i++) {
    const voteOption = data[i][1]; // Assuming 'Vote' is the second column (index 1)
    if (voteOption) {
      votes[voteOption] = (votes[voteOption] || 0) + 1;
    }
  }

  return ContentService.createTextOutput(JSON.stringify({ success: true, results: votes }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  // ... (existing doPost code from previous step) ...
}
*/

 
